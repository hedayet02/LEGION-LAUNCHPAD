# Legion Launchpad Intel — Vercel-ready

This version fixes the Vercel 404 by putting the static homepage at the project root (`index.html`). The previous deployment used a legacy `builds`/`routes` setup that could leave `/` unresolved.

## Deploy
1. Import this folder/repository into Vercel.
2. Leave **Root Directory** as `.` (the repository root).
3. Do not set a Build Command.
4. Do not set an Output Directory.
5. Add `OPENAI_API_KEY` as an environment variable if you want AI analysis.
6. Optionally add `OPENAI_MODEL=gpt-5-mini`.
7. Deploy.

The homepage is `/`, and serverless endpoints are `/api/legion` and `/api/analyze`.
