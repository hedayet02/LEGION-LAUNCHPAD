import * as cheerio from "cheerio";

const LEGION_URL = "https://app.legion.cc/app/invest";

function moneyToNumber(s) {
  if (!s) return 0;
  const m = String(s).replace(/[$,]/g,"").match(/([\d.]+)\s*([KMB])?/i);
  if (!m) return 0;
  let n = Number(m[1]);
  const u = (m[2]||"").toUpperCase();
  if (u==="K") n*=1e3; else if (u==="M") n*=1e6; else if (u==="B") n*=1e9;
  return n;
}

export default async function handler(req, res) {
  try {
    const r = await fetch(LEGION_URL, {
      headers: { "User-Agent": "Legion-Launchpad-Intel/1.0" },
      cache: "no-store"
    });
    if (!r.ok) throw new Error(`Legion returned ${r.status}`);
    const html = await r.text();
    const $ = cheerio.load(html);
    const body = $("body").text().replace(/\s+/g," ").trim();
    const sales = [];
    const known = new Set();

    $("tr").each((_, tr) => {
      const cells = $(tr).find("th,td").map((i,e)=>$(e).text().trim()).get().filter(Boolean);
      if (cells.length < 3) return;
      const name = cells[0];
      const amount = cells.find(x => /^\$[\d,.]+(?:[KMB])?$/i.test(x));
      if (!name || !amount || /^(name|project)$/i.test(name)) return;
      sales.push({name, amountRaised:moneyToNumber(amount), amountRaisedDisplay:amount, raw:cells.join(" | ")});
      known.add(name.toLowerCase());
    });

    for (const name of ["Jumper","Open Delta"]) {
      if (new RegExp(name,"i").test(body) && !known.has(name.toLowerCase())) {
        sales.unshift({
          name, live:true,
          raw:body.slice(Math.max(0,body.toLowerCase().indexOf(name.toLowerCase())-300),
                         body.toLowerCase().indexOf(name.toLowerCase())+900)
        });
      }
    }

    res.status(200).json({
      sales,
      signals:{
        source:LEGION_URL,
        fetchedAt:new Date().toISOString(),
        liveSalesDetected:(body.match(/Live sales/gi)||[]).length,
        pastSalesDetected:(body.match(/Past sales/gi)||[]).length
      },
      rawText:body.slice(0,30000)
    });
  } catch (e) {
    res.status(502).json({error:"Could not read Legion right now.", detail:e.message});
  }
}
