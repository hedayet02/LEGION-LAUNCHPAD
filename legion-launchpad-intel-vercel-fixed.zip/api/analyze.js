import OpenAI from "openai";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({error:"POST required"});
  if (!process.env.OPENAI_API_KEY) {
    return res.status(400).json({error:"OPENAI_API_KEY is not configured in Vercel."});
  }

  const {project, context} = req.body || {};
  if (!project) return res.status(400).json({error:"Missing project data."});

  const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const prompt = `You are a crypto launchpad diligence analyst. Analyze this Legion launchpad project using ONLY the supplied data. Do not invent facts. Separate facts from inference.

Project data:
${JSON.stringify(project, null, 2)}

Legion context:
${String(context||"").slice(0,12000)}

Return JSON:
{
 "verdict":"STRONG|WATCH|HIGH_RISK|INSUFFICIENT_DATA",
 "score":0-100,
 "summary":"2-3 sentences",
 "positives":["..."],
 "risks":["..."],
 "questions":["..."],
 "allocationView":"one sentence about what an applicant should investigate before pledging"
}

Scoring guidance:
25% sale structure/transparency
20% demand/pricing signals
20% project traction/evidence
20% token/vesting/FDV information if supplied
15% risk flags
Missing data lowers confidence; it is not automatically a negative fact.`;

  try {
    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      temperature: 0.2,
      response_format: {type:"json_object"},
      messages:[
        {role:"system",content:"Return valid JSON only."},
        {role:"user",content:prompt}
      ]
    });
    res.status(200).json(JSON.parse(response.choices?.[0]?.message?.content || "{}"));
  } catch (e) {
    res.status(500).json({error:"AI analysis failed.", detail:e.message});
  }
}
