# Legion Launchpad Intel — Vercel

Mobile-first Legion launchpad intelligence dashboard.

## One-click Vercel deployment
1. Upload this folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Deploy with the default settings.
4. In **Project → Settings → Environment Variables**, add:
   - `OPENAI_API_KEY`
   - `OPENAI_MODEL` = `gpt-5-mini`
5. Redeploy.

The app uses Vercel serverless functions under `/api`, so no Express server or local Node process is required.

## Notes
The Legion page is dynamic and its public HTML structure can change. The parser intentionally avoids inventing tokenomics or diligence facts.
AI output is research assistance, not financial advice.
